background.LoadTexture("mainTex", "bg.png")

function render_bg(deltaTime)
  background.DrawShader()
end
